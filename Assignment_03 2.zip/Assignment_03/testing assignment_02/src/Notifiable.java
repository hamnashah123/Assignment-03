public interface Notifiable {
    void sendNotification(String recipientEmail, String message);
}