import javax.sound.midi.Soundbank;
import java.util.Scanner;
/*
 * Main application class for the Health Monitoring System.
 * Handles user interactions and coordinates between different system components.
 */
public class Health_System_App {
    // Shared scanner for user input across all methods
    private static Scanner scanner = new Scanner(System.in);
    // System administrator with predefined credentials
    private static Administrator admin = new Administrator("01", "System Admin", "System Administrator");
    // Database for storing patient vitals
    private static Vitals_Database vitals_DB = new Vitals_Database();
    // Manager for handling appointments
    private static Appointment_Manager app_Manager = new Appointment_Manager();

    // Notification system
    private static Notifiable emailNotification = new EmailNotifications();
    private static Notifiable smsNotification = new SMSNotification();
    // Initialize with notification service
    private static NotificationService notificationService = new NotificationService(new EmailNotifications(), new SMSNotification());
    private static String zoomLink = "https://zoom.us/j/1234567890";

    // Services
    private static ReminderService reminderService = new ReminderService(emailNotification, smsNotification);
    private static EmergencyAlert alert = new EmergencyAlert(notificationService);
    private static PanicButton panicButton = new PanicButton(new EmergencyAlert(notificationService), notificationService);
    private static VideoCall videoCall = new VideoCall(zoomLink);
    private static ChatServer chatServer = new ChatServer();



    //  Displays menu and processes.
    public static void main(String[] args) {
        while (true) {
            System.out.println("\n\t=== Health Monitoring System ===\n");
            System.out.println("1. Add Patient");
            System.out.println("2. Add Doctor");
            System.out.println("3. Upload Vitals");
            System.out.println("4. Schedule Appointment");
            System.out.println("5. Provide Feedback");
            System.out.println("6. View All Data");
            System.out.println("7. Trigger Panic Button");
            System.out.println("8  Start Video Call");
            System.out.println("9  Chat(Doctor And Patient)");
            System.out.println("10 Schedule Reminder");
            System.out.println("0. Exit");
            System.out.print("Choose option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addNewPatient();
                    break;
                case 2:
                    addNewDoctor();
                    break;
                case 3:
                    uploadPatientVitals();
                    break;
                case 4:
                    scheduleAppointment();
                    break;
                case 5:
                    provideDoctorFeedback();
                    break;
                case 6:
                    display_All_Data();
                    break;
                case 7: // Panic Button
                    System.out.print("Enter Patient ID: ");
                    String patientId = scanner.nextLine();
                    Patient patient = find_Patient(patientId);
                    if (patient != null && !patient.getVitals().isEmpty()) {
                        Vital_Sign latest = patient.getVitals().get(patient.getVitals().size() - 1);
                        panicButton.press(latest, patient);
                    }
                    break;

                case 8: // Video Call
                    System.out.print("Enter Patient ID: ");
                    patientId = scanner.nextLine();
                    patient = find_Patient(patientId);
                    if (patient != null) {
                        videoCall.joinCall(patient.getName());
                    }
                    break;

                case 9: // Doctor-Patient Chat
                    System.out.print("Enter Doctor ID: ");
                    Doctor doctor = findDoctor(scanner.nextLine());
                    System.out.print("Enter Patient ID: ");
                    Patient patient1 = find_Patient(scanner.nextLine());

                    if (doctor != null && patient1 != null) {
                        chatServer.clearHistory();
                        ChatClient doctorChat = new ChatClient("Dr." + doctor.getName(), chatServer);
                        ChatClient patientChat = new ChatClient("Patient " + patient1.getName(), chatServer);

                        System.out.println("\n=== Chat Session ===");
                        System.out.println("Type 'bye' to return to main menu\n");

                        boolean chatting = true;
                        while (chatting) {
                            // Doctor's turn
                            System.out.println("\n[Doctor's turn]");
                            chatting = doctorChat.sendMessage();
                            if (!chatting) break;

                            // Patient's turn
                            System.out.println("\n[Patient's turn]");
                            chatting = patientChat.sendMessage();
                        }

                        chatServer.displayHistory();
                        System.out.println("\nReturning to main menu...");
                    } else {
                        System.out.println("Doctor or Patient not found!");
                    }
                    break;
                case 10:

                    System.out.print("Enter Patient Email: ");
                    String patientEmail = scanner.nextLine();

                    System.out.print("Enter Reminder Message: ");
                    String reminderMsg = scanner.nextLine();

                    System.out.println("sending Email...This may take a while...");
                    Notifiable emailNotifier = new EmailNotifications();
                    ReminderService scheduleReminder = new ReminderService(emailNotification, smsNotification);


                    emailNotifier.sendNotification(patientEmail, reminderMsg);

                    break;


                case 0:
                    exit_System();
                    break;
                default:
                    System.out.println("Invalid choice!");
                    continue;
            }
        }
    }

    // Creates a new patient via user input
    private static void addNewPatient() {
        Patient patient = Patient.create_Patient(scanner);
        admin.addPatient(patient);
        System.out.println("Patient added successfully!");
    }

    // Creates a new doctor via user input
    private static void addNewDoctor() {
        Doctor doctor = Doctor.create_Doctor(scanner);
        admin.addDoctor(doctor);
        System.out.println("Doctor added successfully!");
    }

    // Handles vital signs upload for an existing patient
    private static void uploadPatientVitals() {
        System.out.print("Enter Patient ID: ");
        String patientId = scanner.nextLine();

        Patient patient = find_Patient(patientId);
        if (patient != null) {
            patient.upload_Vitals(scanner);
            vitals_DB.add_Vitals(patient.getVitals().get(0)); // Adds first vitals entry to DB
        } else {
            System.out.println("Patient not found!");
        }
    }

    private static void scheduleAppointment() {
        app_Manager.schedule_Appointment(scanner);
    }

    // Handles feedback
    private static void provideDoctorFeedback() {
        System.out.print("Enter Doctor ID: ");
        String docId = scanner.nextLine();
        Doctor doctor = findDoctor(docId);

        System.out.print("Enter Patient ID: ");
        String patId = scanner.nextLine();
        Patient patient = find_Patient(patId);

        if (doctor != null && patient != null) {
            doctor.provide_Feedback(scanner, patient);
        } else {
            System.out.println("Doctor or Patient not found!");
        }
    }

   // display all data to user
    private static void display_All_Data() {
        admin.display_All_Users();
        vitals_DB.display_All_Vitals();
        app_Manager.displayAllAppointments();

        System.out.println("\n\t=== Patient Feedback Centre ===");
        for (Patient patient : admin.getPatients()) {
            System.out.println("\nPatient: " + patient.getName() + " (ID: " + patient.getId() + ")");
            patient.get_Medical_History().display_Feedback();
        }
    }

    private static void handlePanicButton() {
        System.out.print("Enter Patient ID: ");
        String patientId = scanner.nextLine();
        Patient patient = find_Patient(patientId);

        if (patient != null && !patient.getVitals().isEmpty()) {
            Vital_Sign latest = patient.getVitals().get(patient.getVitals().size() - 1);
            panicButton.press(latest, patient);
        } else {
            System.out.println("Patient not found or no vitals available!");
        }
    }
    // Cleanly exits the application
    private static void exit_System() {
        System.out.println("\n\tExiting system.....");
        scanner.close();
        System.exit(0);
    }

    //  method to find patient by ID
    private static Patient find_Patient(String id) {
        for (Patient p : admin.getPatients()) {
            if (p.getId().equals(id)) {
                return p;
            }
        }
        return null;
    }

    //  find doctor by ID
    private static Doctor findDoctor(String id) {
        for (Doctor d : admin.getDoctors()) {
            if (d.getId().equals(id)) {
                return d;
            }
        }
        return null;
    }
}