import java.util.Timer;
import java.util.TimerTask;

public class ReminderService {
    private Notifiable emailNotification;
//    private Notifiable smsNotification;

    public ReminderService(Notifiable email, Notifiable sms) {
        this.emailNotification = email;
//        this.smsNotification = sms;
    }
    //Schedules a reminder to be sent after a delay
    public void scheduleReminder(String userId, String message, long delayInMillis) {
        Timer timer = new Timer();
        // Schedule the task to run after the specified delay
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                emailNotification.sendNotification(userId, message);
//                smsNotification.sendNotification(userId, message);
            }
        }, delayInMillis);
    }
}