import java.util.ArrayList;
import java.util.List;

public class Vitals_Database {
    // Stores all vital sign records in the system
    private List<Vital_Sign> vitalsList;

    //Initializes an empty database for vital signs
    public Vitals_Database() {
        vitalsList = new ArrayList<>();
    }

     // Adds a new vital sign record to the database
    public void add_Vitals(Vital_Sign vital) {
        vitalsList.add(vital);
    }

    // Displays all vital sign records in the system
    public void display_All_Vitals() {
        System.out.println("\n\t--- All Vital Signs ---");
        for (Vital_Sign v : vitalsList) {
            v.display_Vitals();
        }
    }
}