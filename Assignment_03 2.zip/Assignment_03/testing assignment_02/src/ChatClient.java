import java.util.Scanner;

public class ChatClient {
    private String username;
    private ChatServer server;
    private Scanner scanner;

    public ChatClient(String username, ChatServer server) {
        this.username = username;
        this.server = server;
        this.scanner = new Scanner(System.in);
    }

    public boolean sendMessage() {
        System.out.print(username + " > ");
        String message = scanner.nextLine();

        if (message.equalsIgnoreCase("bye")) {
            server.receiveMessage(username + " left the chat");
            return false;
        }

        server.receiveMessage(username + ": " + message);
        return true;
    }
}