import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Appointment_Manager {
    // Stores all scheduled appointments
    private List<Appointment> appointments;

    public Appointment_Manager() {
        appointments = new ArrayList<>();
    }

    // method to schedule new appointments by input
    public void schedule_Appointment(Scanner scanner) {
        System.out.println("\n\t--- Schedule Appointment ---");
        System.out.print("Appointment ID: ");
        String appId = scanner.nextLine();
        System.out.print("Patient ID: ");
        String patientId = scanner.nextLine();
        System.out.print("Doctor ID: ");
        String doctorId = scanner.nextLine();
        System.out.print("Date (YYYY-MM-DD): ");
        String date = scanner.nextLine();

        Appointment appointment = new Appointment(appId, patientId, doctorId, date);
        appointments.add(appointment);
        System.out.println("Appointment scheduled successfully!");
    }

    //Displays all appointments in the system
    public void displayAllAppointments() {
        System.out.println("\n\t--- All Appointments ---");
        for (Appointment a : appointments) {
            a.display_Appointment();
        }
    }
}