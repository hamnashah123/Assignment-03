public class NotificationService {
    private Notifiable emailNotification;
    private Notifiable smsNotification;

    public NotificationService(Notifiable emailNotification, Notifiable smsNotification) {
        this.emailNotification = emailNotification;
        this.smsNotification = smsNotification;
    }

    public void sendEmergencyAlert(String email, String phone, String message) {
        try {
            if (email != null && !email.isEmpty()) {
                emailNotification.sendNotification(email, "🚨 EMERGENCY ALERT\n" + message);
            }

            if (phone != null && !phone.isEmpty()) {
                smsNotification.sendNotification(phone, "EMERGENCY: " + message);
            }
        } catch (Exception e) {
            System.out.println("⚠ Alert partially failed: " + e.getMessage());
        }
    }
}