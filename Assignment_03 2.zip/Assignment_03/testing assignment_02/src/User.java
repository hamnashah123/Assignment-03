import java.util.Scanner;

public class User {
    // Protected fields to be inherited by child classes
    protected String id;
    protected String name;
    protected String designation;

    public User(String id, String name, String designation) {
        this.id = id;
        this.name = name;
        this.designation = designation;
    }

    // getters
    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getDesignation() {
        return this.designation;
    }

    //  method to create new user by input
    public static User createUser(Scanner scanner, String userType) {
        System.out.println("\n--- Create New " + userType + " ---");
        System.out.print("Enter ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Designation: ");
        String designation = scanner.nextLine();

        return new User(id, name, designation);
    }

    //Displays basic user information in console
    public void display_Info() {
        System.out.println("\t\tDoctor Information:");
        System.out.println("ID: " + this.id);
        System.out.println("Name: " + this.name);
        System.out.println("Designation: " + this.designation);
    }
}